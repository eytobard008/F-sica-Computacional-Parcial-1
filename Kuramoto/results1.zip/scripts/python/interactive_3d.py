import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import os

def plot_3d_phase_space_superposed():
    fig = plt.figure(figsize=(12, 8), num='Espacio de Fases 3D - Superpuesto')
    ax = fig.add_subplot(111, projection='3d')
    
    data_files = [f for f in os.listdir('results/datos/3osc/') if f.startswith('phase_space_3d_K')]
    colors = ['red', 'blue', 'green', 'orange']
    
    for idx, data_file in enumerate(data_files):
        K_value = data_file.split('_K')[1].replace('.dat', '')
        try:
            data = np.loadtxt('results/datos/3osc/' + data_file, skiprows=1)
            if len(data) > 0:
                color = colors[idx % len(colors)]
                ax.plot(data[:,0], data[:,1], data[:,2], label=f'K={K_value}', alpha=0.7, color=color)
        except Exception as e:
            print(f'Error: {e}')
    
    ax.set_xlabel('θ₁')
    ax.set_ylabel('θ₂')
    ax.set_zlabel('θ₃')
    ax.set_title('Espacio de Fases 3D - Todas las K (Superpuestas)')
    ax.legend()
    plt.show(block=False)

def plot_3d_alpha_phase_space_separated():
    data_files = [f for f in os.listdir('results/datos/3osc/') if f.startswith('alpha_phase_space_3d')]
    
    for data_file in data_files:
        K_value = data_file.split('_K')[1].replace('.dat', '')
        try:
            data = np.loadtxt('results/datos/3osc/' + data_file, skiprows=1)
            
            if len(data) > 0:
                fig = plt.figure(figsize=(10, 8))
                ax = fig.add_subplot(111, projection='3d')
                ax.plot(data[:,0], data[:,1], data[:,2], alpha=0.7, color='purple')
                ax.set_xlabel('α₁ = cos(θ₁)')
                ax.set_ylabel('α₂ = cos(θ₂)')
                ax.set_zlabel('α₃ = cos(θ₃)')
                ax.set_title(f'Espacio de Fases 3D - Coordenadas Alpha - K={K_value}')
                ax.set_xlim([-1.1, 1.1])
                ax.set_ylim([-1.1, 1.1])
                ax.set_zlim([-1.1, 1.1])
                plt.show(block=False)
        except Exception as e:
            print(f'Error: {e}')

def plot_3d_fixed_points_with_cuts():
    data_files = [f for f in os.listdir('results/datos/3osc/') if f.startswith('fixed_points_3d')]
    
    for data_file in data_files:
        K_value = data_file.split('_K')[1].replace('.dat', '')
        try:
            data = np.loadtxt('results/datos/3osc/' + data_file, skiprows=1)
            
            if len(data) > 0:
                n = int(np.sqrt(len(data)))
                X = data[:,0].reshape(n, n)
                Y = data[:,1].reshape(n, n)
                Z = data[:,2].reshape(n, n)
                
                fig = plt.figure(figsize=(12, 8))
                ax = fig.add_subplot(111, projection='3d')
                
                # Superficie
                surf = ax.plot_surface(X, Y, Z, alpha=0.7, cmap='viridis')
                
                # Marcar cortes con plano z=0
                zero_crossings = np.where(np.abs(Z) < 0.1)  # Umbral para cortes
                if len(zero_crossings[0]) > 0:
                    ax.scatter(X[zero_crossings], Y[zero_crossings], 
                              Z[zero_crossings], color='red', s=50, label='Cortes con z=0')
                
                # Líneas de contorno en plano base
                contour = ax.contour(X, Y, Z, zdir='z', offset=np.min(Z), cmap='viridis')
                
                ax.set_xlabel('Δ₂₁')
                ax.set_ylabel('Δ₃₁')
                ax.set_zlabel('|dΔ/dt|')
                ax.set_title(f'Puntos Fijos 3D - K={K_value}')
                ax.legend()
                fig.colorbar(surf)
                plt.show(block=False)
        except Exception as e:
            print(f'Error: {e}')

if __name__ == '__main__':
    print('Mostrando gráficas 3D interactivas...')
    plot_3d_phase_space_superposed()
    plot_3d_alpha_phase_space_separated()
    plot_3d_fixed_points_with_cuts()
    print('Cierra cada ventana para continuar...')
    plt.show()
